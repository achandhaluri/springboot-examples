package com.example.demo;

import com.example.demo.entity.Event;
import com.example.demo.entity.Student;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class StudentEventIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private EventRepository eventRepository;

    @BeforeEach
    void cleanDb() {
        eventRepository.deleteAll();
        studentRepository.deleteAll();
    }

    @Test
    void testCreateAndGetStudent() throws Exception {
        String studentJson = "{\"name\":\"Alice\",\"email\":\"alice@example.com\"}";

        mockMvc.perform(post("/students")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(studentJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Alice")))
                .andExpect(jsonPath("$.email", is("alice@example.com")))
                .andExpect(jsonPath("$.eventIds", hasSize(0)));

        mockMvc.perform(get("/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name", is("Alice")));
    }

    @Test
    void testCreateAndGetEvent() throws Exception {
        String eventJson = "{\"eventName\":\"Math Olympiad\",\"description\":\"Annual competition\"}";

        mockMvc.perform(post("/events")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(eventJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName", is("Math Olympiad")))
                .andExpect(jsonPath("$.studentIds", hasSize(0)));

        mockMvc.perform(get("/events"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].eventName", is("Math Olympiad")));
    }

    @Test
    void testAddStudentToEvent() throws Exception {
        Student student = studentRepository.save(
                Student.builder().name("Bob").email("bob@example.com").build()
        );

        Event event = eventRepository.save(
                Event.builder().eventName("Science Fair").description("School event").build()
        );

        mockMvc.perform(post("/students/{studentId}/events/{eventId}", student.getId(), event.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName", is("Science Fair")))
                .andExpect(jsonPath("$.studentIds", hasSize(1)))
                .andExpect(jsonPath("$.studentIds[0]", is(student.getId().intValue())));

        mockMvc.perform(get("/students/{id}", student.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventIds", containsInAnyOrder(event.getId().intValue())));
    }

    @Test
    void testGetNonExistingStudent() throws Exception {
        mockMvc.perform(get("/students/999"))
                .andExpect(status().is5xxServerError()); // custom exception handler can improve this
    }

    @Test
    void testGetNonExistingEvent() throws Exception {
        mockMvc.perform(get("/events/999"))
                .andExpect(status().is5xxServerError()); // custom exception handler can improve this
    }
}
