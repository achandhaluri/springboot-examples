package com.example.demo.util;

import com.example.demo.dto.EventDTO;
import com.example.demo.dto.StudentDTO;
import com.example.demo.entity.Event;
import com.example.demo.entity.Student;
import java.util.stream.Collectors;

public class MapperUtil {

    public static StudentDTO toStudentDTO(Student student) {
        return new StudentDTO(
            student.getId(),
            student.getName(),
            student.getEmail(),
            student.getEvents().stream().map(Event::getId).collect(Collectors.toSet())
        );
    }

    public static EventDTO toEventDTO(Event event) {
        return new EventDTO(
            event.getId(),
            event.getEventName(),
            event.getDescription(),
            event.getStudents().stream().map(Student::getId).collect(Collectors.toSet())
        );
    }
}
