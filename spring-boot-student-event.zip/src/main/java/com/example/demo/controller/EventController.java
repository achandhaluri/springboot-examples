package com.example.demo.controller;

import com.example.demo.dto.EventDTO;
import com.example.demo.service.EventService;
import com.example.demo.util.MapperUtil;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;
    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping
    public EventDTO createEvent(@RequestBody EventDTO dto) {
        return MapperUtil.toEventDTO(eventService.createEvent(dto));
    }

    @GetMapping
    public List<EventDTO> getAllEvents() {
        return eventService.getAllEvents().stream()
                .map(MapperUtil::toEventDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public EventDTO getEvent(@PathVariable Long id) {
        return MapperUtil.toEventDTO(eventService.getEvent(id));
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
    }
}
