package com.example.demo.controller;

import com.example.demo.dto.StudentDTO;
import com.example.demo.dto.EventDTO;
import com.example.demo.service.StudentService;
import com.example.demo.util.MapperUtil;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping
    public StudentDTO createStudent(@RequestBody StudentDTO dto) {
        return MapperUtil.toStudentDTO(studentService.createStudent(dto));
    }

    @GetMapping
    public List<StudentDTO> getAllStudents() {
        return studentService.getAllStudents().stream()
                .map(MapperUtil::toStudentDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public StudentDTO getStudent(@PathVariable Long id) {
        return MapperUtil.toStudentDTO(studentService.getStudent(id));
    }

    @DeleteMapping("/{id}")
    public void deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
    }

    @PostMapping("/{studentId}/events/{eventId}")
    public EventDTO addStudentToEvent(@PathVariable Long studentId, @PathVariable Long eventId) {
        return MapperUtil.toEventDTO(studentService.addStudentToEvent(studentId, eventId));
    }
}
