package com.example.demo.service;

import com.example.demo.dto.StudentDTO;
import com.example.demo.entity.Event;
import com.example.demo.entity.Student;
import com.example.demo.repository.EventRepository;
import com.example.demo.repository.StudentRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final EventRepository eventRepository;

    public StudentService(StudentRepository studentRepository, EventRepository eventRepository) {
        this.studentRepository = studentRepository;
        this.eventRepository = eventRepository;
    }

    public Student createStudent(StudentDTO dto) {
        Student student = Student.builder()
            .name(dto.getName())
            .email(dto.getEmail())
            .build();
        return studentRepository.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudent(Long id) {
        return studentRepository.findById(id).orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new RuntimeException("Student not found");
        }
        studentRepository.deleteById(id);
    }

    public Event addStudentToEvent(Long studentId, Long eventId) {
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new RuntimeException("Student not found"));
        Event event = eventRepository.findById(eventId)
            .orElseThrow(() -> new RuntimeException("Event not found"));

        event.getStudents().add(student);
        student.getEvents().add(event);

        return eventRepository.save(event);
    }
}
